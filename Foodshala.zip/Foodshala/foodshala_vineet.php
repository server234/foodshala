<?php
  session_start();
    $conn = mysqli_connect('localhost' ,'root' ,'','foodshala');
    $login_id = $_SESSION['email_login'];


//###################################### for SignUp#####################################################
#######################################################################################################//
  if(isset($_POST['submit']) !=''){
     $type_check = $_POST['type_check'];
     $email_id = $_POST['email_id'];
     $name = $_POST['name'];
     $food_type = $_POST['food_type'];
     $password = $_POST['password'];

//#######################################for Customers SignUp###########################################
######################################################################################################//
     if($type_check =='1'){
       $sql_customer = mysqli_query($conn ,"INSERT INTO SignUp_Customers(Customer_name , email_d ,food_type,password,Customer_id)Values('".$name."','".$email_id."','".$food_type."','".$password."','1') ");
   
       }


//######################################for Restaurants Login #########################################
#####################################################################################################//
     if($type_check =='2'){
       $sql_customer = mysqli_query($conn ,"INSERT INTO SignUp_Restaurants(Name, email_d ,password,Restaurants_id)Values('".$name."','".$email_id."','".$password."','2') ");
  
      }
  
   }


//######################################## For LogIn #################################################
######################################################################################################//

    
  if(isset($_POST['login'])!=''){
     $type_check_login = $_POST['type_check_login'];
     $email_login = $_POST['email_login'];
     $_SESSION['email_login'] = $email_login;
     $password_login = $_POST['password_login'];
     
    if($type_check_login == '1'){
       $sql_login = mysqli_query($conn ,"select * from SignUp_Customers where email_d ='".$email_login."' && password='".$password_login."'");
     
        $row = mysqli_num_rows($sql_login);
    
     if($row != '0'){
        ?><script>
        alert("login successfully !!");
         </script>
       <?} 
     }

    if($type_check_login == '2'){
       $sql_login_1 = mysqli_query($conn ,"select * from SignUp_Restaurants where email_d ='".$email_login."' && password='".$password_login."'");
      $row_1 = mysqli_num_rows($sql_login_1);
       if($row_1 != '0'){
       ?><script>
        alert("login successfully !!");
        </script>
       <?} 
 
     }
 }

 //########################################### ADD RESTAURANTS################################################################################################################################################//
  
  if(isset($_POST['add_Restaurants'])!=''){

    $Restaurants_mail = $_POST['Restaurants_mail'];
    $Restaurants_name = $_POST['Restaurants_name'];
    $Restaurants_location = $_POST['Restaurants_location'];

    $Restaurants_sql = mysqli_query($conn ,"select * from SignUp_Restaurants where email_d='".$Restaurants_mail."'");

    $Rest_id = mysqli_fetch_array($Restaurants_sql);
  if($Rest_id['Restaurants_id'] == '2'){
     $Add_rest = mysqli_query($conn ,"Insert Into Add_Restaurants(email_id ,Restaurants_name ,location ,Restaurants_id)Values('".$Restaurants_mail."','".$Restaurants_name."','".$Restaurants_location."','2')");
  }else{
    ?><script>
       alert("you need to signUp as Restaurants Owner!!");
    </script>
    <?}
 }

 //########################################## ADD RESTAURANTS END ##################################
 #################################################################################################//
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      <title>Login FoodShala</title>
      <link rel="stylesheet" href="style.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
      <script>
var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
</script>
    <style>
      @import url('https://fonts.googleapis.com/css?family=Poppins:400,500,600,700&display=swap');
   *{
    margin: 0;
    padding: 0;
    outline: none;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
  }
body{
  height: 100vh;
  width: 100%;
  background: linear-gradient(115deg, #fff 10%, #fff 90%);
}
* {
  box-sizing: border-box;
}

form.input-group input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 55%;
  background: #f1f1f1;
  border-radius: 25px;
}

form.input-group button:hover {
  background: #0b7dda;
}

form.input-group::after {
  content: "";
  clear: both;
  display: table;
}
.input-group{
   margin-top:-51px; 
   margin-left: 300px;
}
.logo{
   margin-top:35px; 
   margin-left: 30px;
}
.show-btn_1{
  background: #fff;
  padding: 10px 20px;
  font-size: 20px;
  font-weight: 500;
  color: #3498db;
  cursor: pointer;
  margin-top:-280px;
  margin-left: 470px;
  border : none;
  box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
}
.show-btn_2{
  background: #fff;
  padding: 10px 20px;
  font-size: 20px;
  font-weight: 500;
  color: #3498db;
  cursor: pointer;
  margin-top:-110px;
  margin-left: 430px;
  border : none;
  box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
}
.show-btn{
  background: #fff;
  padding: 10px 20px;
  font-size: 20px;
  font-weight: 500;
  color: #3498db;
  cursor: pointer;
  margin-top: -280px;
  margin-left: 300px;
  border :none;
  box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
}
.show-btn_1, .container_1{
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
.show-btn_2, .container_2{
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
.show-btn, .container{
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

input[type="checkbox"]{
  display: none;
}
.container{
  display: none;
  background: #fff;
  width: 410px;
  padding: 30px;
  box-shadow: 0 0 8px rgba(0,0,0,0.1);
}
.container_1{
  display: none;
  background: #fff;
  width: 410px;
  padding: 30px;
  box-shadow: 0 0 8px rgba(0,0,0,0.1);
}
.container_2{
  display: none;
  background: #fff;
  width: 410px;
  padding: 30px;
  box-shadow: 0 0 8px rgba(0,0,0,0.1);
}
#show:checked ~ .container{
  display: block;
}
#show_1:checked ~ .container_1{
  display: block;
}
#show_2:checked ~ .container_2{
  display: block;
}
.container_1 .close-btn{
  position: absolute;
  right: 20px;
  top: 15px;
  font-size: 18px;
  cursor: pointer;
}
.container_2 .close-btn{
  position: absolute;
  right: 20px;
  top: 15px;
  font-size: 18px;
  cursor: pointer;
}
.container .close-btn{
  position: absolute;
  right: 20px;
  top: 15px;
  font-size: 18px;
  cursor: pointer;
}
.container .close-btn:hover{
  color: #3498db;
}
.container_1 .close-btn:hover{
  color: #3498db;
}
.container_2 .close-btn:hover{
  color: #3498db;
}
.container .text{
  font-size: 35px;
  font-weight: 600;
  text-align: center;
}
.container_1 .text{
  font-size: 35px;
  font-weight: 600;
  text-align: center;
}
.container_2 .text{
  font-size: 35px;
  font-weight: 600;
  text-align: center;
}
.container form{
  margin-top: -20px;
}
.container_1 form{
  margin-top: -20px;
}
.container_2 form{
  margin-top: -20px;
}
.container form .data{
  height: 45px;
  width: 100%;
  margin: 40px 0;
}
.container_1 form .data{
  height: 45px;
  width: 100%;
  margin: 40px 0;
}
.container_2 form .data{
  height: 45px;
  width: 100%;
  margin: 40px 0;
}
form .data label{
  font-size: 18px;
}
form .data input {
  height: 100%;
  width: 100%;
  padding-left: 10px;
  font-size: 17px;
  border: 1px solid silver;
}
form .data input:focus{
  border-color: #3498db;
  border-bottom-width: 2px;
}
form .data select {
  height: 100%;
  width: 100%;
  padding-left: 10px;
  font-size: 17px;
  border: 1px solid silver;
}
form .data select:focus{
  border-color: #3498db;
  border-bottom-width: 2px;
}
form .forgot-pass{
  margin-top: -8px;
}
form .forgot-pass a{
  color: #3498db;
  text-decoration: none;
}
form .forgot-pass a:hover{
  text-decoration: underline;
}
form .btn{
  margin: 30px 0;
  height: 45px;
  width: 100%;
  position: relative;
  overflow: hidden;
}
form .btn .inner{
  height: 100%;
  width: 300%;
  position: absolute;
  left: -100%;
  z-index: -1;
  background: -webkit-linear-gradient(right, #56d8e4, #9f01ea, #56d8e4, #9f01ea);
  transition: all 0.4s;
}
form .btn:hover .inner{
  left: 0;
}
form .btn button{
  height: 100%;
  width: 100%;
  background: none;
  border: none;
  color: #fff;
  font-size: 18px;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 1px;
  cursor: pointer;
}
form .signup-link{
  text-align: center;
}
form .signup-link a{
  color: #3498db;
  text-decoration: none;
}
form .signup-link a:hover{
  text-decoration: underline;
}
  
  /* CSS for food menu */

* {
  box-sizing: border-box;
}

img {
  vertical-align: middle;
}

.swipe {
   margin-left: 40px;
   margin-top: 10px;
   margin-right: 40px;
  position: relative;
  }

/* Hide the images by default */
.mySlides {
  display: none;
}

/* Add a pointer when hovering over the thumbnail images */
.cursor {
  cursor: pointer;
}

/* Next & previous buttons */
.prev,
.next {
  cursor: pointer;
  position: absolute;
  top: 40%;
  width: auto;
  padding: 16px;
  margin-top: -50px;
  color: white;
  font-weight: bold;
  font-size: 20px;
  border-radius: 0 3px 3px 0;
  user-select: none;
  -webkit-user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover,
.next:hover {
  background-color: rgba(0, 0, 0, 0.8);
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* Container for image text */
.caption-container {
  text-align: center;
  background-color: #222;
  padding: 2px 16px;
  color: white;

}

.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Six columns side by side */
.column {
  float: left;
  width: 16.66%;
}

/* Add a transparency effect for thumnbail images */
.demo {
  opacity: 0.8;
}

.active,
.demo:hover {
  opacity: 1;
}
/* CSS for food menu  */
  </style>
  </head>
   <body>
  
      <h6 style="margin-top: 0px; color: green">User with ID:<?$login_id;?> is Logged IN</h6>
      <h1 class = "logo" style="color:Black;"><p><i><strong>FOODSHALA</strong></i></p></h1>
      <form class="input-group">
      <input type="text" placeholder="Search.." name="search">
      </form>
      <div class="center">
         <input type="checkbox" id="show">
         <form>
         <label for="show" class="show-btn">Login Form</label>
         </form>
         <input type="checkbox" id="show_1">
         <form>
         <label for="show_1" class="show-btn_1">SignUp Form</label>
        </form>
   <!-- food menu -->
   <h2 style="text-align:center;margin-top: 50px">Food Gallery</h2>
   <h2 style="margin-left: 40px;margin-top: 60px">Food Menu</h2>
   <h6 style=" margin-left: 40px;color: tomato"></h6>
   <input type="checkbox" id="show_2">   
         <form>
         <label for="show_2" class="show-btn_2">Add Restaurants</label>
         </form>
   <div class="swipe">
  <div class="mySlides">
    <div class="numbertext">1 / 6</div>
    <img src="images/image1.jpg" style=" height:300px;width:100%">
  </div>

  <div class="mySlides">
    <div class="numbertext">2 / 6</div>
    <img src="images/image2.jpg" style=" height:300px;width:100%">
  </div>

  <div class="mySlides">
    <div class="numbertext">3 / 6</div>
    <img src="images/image3.jpg" style=" height:300px;width:100%">
  </div>
    
  <div class="mySlides">
    <div class="numbertext">4 / 6</div>
    <img src="images/image4.jpg" style=" height:300px;width:100%">
  </div>

  <div class="mySlides">
    <div class="numbertext">5 / 6</div>
    <img src="images/image5.jpg" style=" height:300px;width:100%">
  </div>
    
  <div class="mySlides">
    <div class="numbertext">6 / 6</div>
    <img src="images/image6.jpg" style=" height:300px;width:100%">
  </div>
    
  <a class="prev" onclick="plusSlides(-1)">❮</a>
  <a class="next" onclick="plusSlides(1)">❯</a>

  <div class="caption-container">
    <p id="caption"></p>
  </div>

  <div class="row">
    <div class="column">
      <img class="demo cursor" src="images/image1.jpg" style="width:100%" onclick="currentSlide(1);order(alert('Order Food Successfully!!'));" alt="Order Now">
    </div>
    <div class="column">
      <img class="demo cursor" src="images/image2.jpg" style="width:100%" onclick="currentSlide(2);order(alert('Order Food Successfully!!'));" alt="Order Now">
    </div>
    <div class="column">
      <img class="demo cursor" src="images/image3.jpg" style="width:100%" onclick="currentSlide(3);order(alert('Order Food Successfully!!'));" alt="Order Now">
    </div>
    <div class="column">
      <img class="demo cursor" src="images/image4.jpg" style="width:100%" onclick="currentSlide(4);order(alert('Order Food Successfully!!'));" alt="Order Now">
    </div>
    <div class="column">
      <img class="demo cursor" src="images/image5.jpg" style="width:100%" onclick="currentSlide(5);order(alert('Order Food Successfully!!'));" alt="Order Now">
    </div>    
    <div class="column">
      <img class="demo cursor" src="images/image6.jpg" style="width:100%" onclick="currentSlide(6)" alt="Order Now">
    </div>
  </div>
</div>
<!-- End food Menu -->
<!-- Login form -->
         <div class="container">
            <label for="show" class="close-btn fas fa-times" title="close"></label>
            <div class="text">
               Login Form
            </div>
            <form action="foodshala_vineet.php" method="post">
               <div class="data">
                  <label>Who are You?</label>
                   <select name="type_check_login" id="type_check_login">
                   <option value="1">Customer</option>
                   <option value="2">Restaurant Owner</option>
                 </select>
                  <input type="hidden" required>
               </div>
               <div class="data">
                  <label>Email Id</label>
                  <input type="text" name="email_login" id="email_login" required>
               </div>
               <div class="data">
                  <label>Password</label>
                  <input type="password" name="password_login" id="password_login" required>
               </div>
               <div class="forgot-pass">
                  <a href="#">Forgot Password?</a>
               </div>
              
               <div class="btn">
                  <div class="inner"></div>
                  <button type="submit" name ="login" id="login">login</button>
               </div>
               <div class="signup-link">
                  Not a member? <a href="foodshala_vineet.php">Signup now</a>
               </div>
            </form>
         </div>
         <!-- Login form End -->
         <!-- signUp form -->
          <div class="container_1">
            <label for="show_1" class="close-btn fas fa-times" title="close"></label>
            <div class="text">
               SignUp Form
            </div>
            <form action="foodshala_vineet.php" method="post">
              <div class="data">
                  <label>Who are You?</label>
                   <select name="type_check" id="type_check">
                   <option value="1">Customer</option>
                   <option value="2">Restaurant Owner</option>
                 </select>
                  <input type="hidden" required>
               </div>
               <div class="data">
                  <label>Email Id</label>
                  <input type="text" name="email_id" id="email_id" required>
               </div>
               <div class="data">
                  <label>Name</label>
                  <input type="text" name="name" id="name" required>
               </div>
               <div class="data">
                  <label>Food Type</label>
                  <select name="food_type" id="food_type">
                   <option value="1">Veg</option>
                   <option value="2">Non-Veg</option>
                 </select>
               </div>
               <div class="data">
                  <label>Password</label>
                  <input type="password"  name ="password" id="password" required>
               </div>
               <div class="forgot-pass">
                  <a href="#">Forgot Password?</a>
               </div>
               <div class="btn">
                  <div class="inner"></div>
                  <button type="submit" name="submit" id="submit">SignUp</button>
               </div>
               <div class="signup-link">
                  Already a Member? <a href="foodshala_vineet.php">Login now</a>
               </div>
            </form>
         </div>
         <!-- signup form end -->
         <!-- To Add Restauramts -->
         <div class="container_2">
            <label for="show_2" class="close-btn fas fa-times" title="close"></label>
            <div class="text">
               Restaurants Details
            </div>
            <form action="foodshala_vineet.php" method="post">
               <div class="data">
                  <label>Email Id</label>
                  <input type="text" name="Restaurants_mail" id="Restaurants_mail" required>
               </div>
               <div class="data">
                  <label>Restaurants Name</label>
                  <input type="text" name="Restaurants_name" id="Restaurants_name" required>
               </div>
              <div class="data">
                  <label>Restaurants Location</label>
                  <input type="text" name="Restaurants_location" id="Restaurants_location" required>
               </div>
               <div class="btn">
                  <div class="inner"></div>
                  <button type="submit" name="add_Restaurants" id="add_restaurants">Add</button>
               </div>
               <div class="signup-link">
                  Not a member? <a href="foodshala_vineet.php">Signup now</a>
               </div>
            </form>
         </div>
         <!-- To Add Restaurants End -->
        </div>
   </body>
</html>