-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 10, 2021 at 05:33 AM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.1.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodshala`
--

-- --------------------------------------------------------

--
-- Table structure for table `Add_Restaurants`
--

CREATE TABLE `Add_Restaurants` (
  `id` int(10) NOT NULL,
  `email_id` text DEFAULT NULL,
  `Restaurants_name` text DEFAULT NULL,
  `location` text DEFAULT NULL,
  `Restaurants_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SignUp_Customers`
--

CREATE TABLE `SignUp_Customers` (
  `id` int(10) NOT NULL,
  `Customer_name` text DEFAULT NULL,
  `email_d` text DEFAULT NULL,
  `food_type` text NOT NULL,
  `password` text NOT NULL,
  `Customer_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SignUp_Restaurants`
--

CREATE TABLE `SignUp_Restaurants` (
  `id` int(10) NOT NULL,
  `Name` text DEFAULT NULL,
  `email_d` text DEFAULT NULL,
  `password` text NOT NULL,
  `Restaurants_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Add_Restaurants`
--
ALTER TABLE `Add_Restaurants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `SignUp_Customers`
--
ALTER TABLE `SignUp_Customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `SignUp_Restaurants`
--
ALTER TABLE `SignUp_Restaurants`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Add_Restaurants`
--
ALTER TABLE `Add_Restaurants`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `SignUp_Customers`
--
ALTER TABLE `SignUp_Customers`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `SignUp_Restaurants`
--
ALTER TABLE `SignUp_Restaurants`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
